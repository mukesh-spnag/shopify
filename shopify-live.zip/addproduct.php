<?php 
require 'vendor/autoload.php';
$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();
$accessToken = "232ab0e756cda6b849f5b829f28f42ad";

$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB'));

/* Select queries return a resultset */
if($result = $db->query("SELECT * FROM installs LIMIT 1")) {
    printf("Select returned %d rows.\n", $result->num_rows);
    if($result->num_rows>0){
        if($result){
             // Cycle through results
            while ($row = $result->fetch_object()){
                $user_arr[] = $row;
            }
            // Free result set
            $result->close();
            $db->next_result();
        }
        $store = $user_arr[0]->store;
        $nonce = $user_arr[0]->nonce;
        $accessToken = $user_arr[0]->access_token;
    }else{
        echo "No result found.";
    }
    /* free result set */
    $result->close();
}

$products_array = array(
                    "product"=>array(
                        'title'=>'',
                        "title"=> "Burton Custom Freestlye 151",
                        "body_html"=> "<strong>Good snowboard!</strong>",
                        "vendor"=> "Burton",
                        "product_type"=> "Snowboard",
                        "published"=> true ,
                        "variants"=>array(
                                    array(
                                        "sku"=>"t_009",
                                        "price"=>20.00,
                                        "grams"=>200,
                                        "taxable"=>false,
                                    )
                        )
                    )
                );

echo json_encode($products_array);

echo "<br />";

//$url = "https://{$store}/admin/oauth/authorize?client_id={$api_key}&scope={$scopes}&redirect_uri={$redirect_uri}&state={$nonce}";

// $url = "https://apikey:password@hostname/admin/products.json";
$url = "https://{$store}/admin/products.json";
// echo "<pre>";
// // print_r($store);
// // print_r($nonce);
// print_r($url);
// die;
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json','X-Shopify-Access-Token: '.$accessToken));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_VERBOSE, 0);
curl_setopt($curl, CURLOPT_HEADER, 1);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($products_array));
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec ($curl);
curl_close ($curl);
echo "<pre>";
print_r($response); 
?>