<?php 
require 'vendor/autoload.php';
$dotenv = new Dotenv\Dotenv(__DIR__);
$dotenv->load();

$db = new Mysqli(getenv('MYSQL_HOST'), getenv('MYSQL_USER'), getenv('MYSQL_PASS'), getenv('MYSQL_DB'));

/* Select queries return a resultset */
if($result = $db->query("SELECT * FROM installs LIMIT 1")) {
    //printf("Select returned %d rows.\n", $result->num_rows);
    if($result->num_rows>0){
        if($result){
             // Cycle through results
            while ($row = $result->fetch_object()){
                $user_arr[] = $row;
            }
            // Free result set
            $result->close();
        }
        $store = $user_arr[0]->store;
        $nonce = $user_arr[0]->nonce;
        $accessToken = $user_arr[0]->access_token;
    }else{
        echo "No result found.";
    }
    /* free result set */
    
}
// $url = "https://apikey:password@hostname/admin/products.json";
$url = "https://{$store}/admin/carrier_services";
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_HTTPHEADER, array('Accept:application/json','Content-Type: application/json','X-Shopify-Access-Token: '.$accessToken));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_VERBOSE, 0);
curl_setopt($curl, CURLOPT_HEADER, 1);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec ($curl);
curl_close ($curl);
echo "<pre>";
print_r($response); 
?>